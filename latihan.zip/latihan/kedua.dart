import 'package:flutter/material.dart';

class Kedua extends StatelessWidget {
  const Kedua ({super.key});

  @override
  Widget build(BuildContext context) {
    // Bagian Judul dan Lokasi
    Widget titleSection = Container(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Pantai Kuta',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Bali, Indonesia',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.favorite,
            color: Colors.pink[400],
          ),
          const SizedBox(width: 4),
          const Text('120'),
        ],
      ),
    );

    // Helper function untuk tombol
    Column buildButtonColumn(Color color, IconData icon, String label) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color),
          Container(
            margin: const EdgeInsets.only(top: 8),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: color,
              ),
            ),
          ),
        ],
      );
    }

    Color color = Theme.of(context).primaryColor;

    // Tombol Aksi
    Widget buttonSection = Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        buildButtonColumn(color, Icons.map, 'MAP'),
        buildButtonColumn(color, Icons.photo, 'PHOTOS'),
        buildButtonColumn(color, Icons.comment, 'REVIEWS'),
      ],
    );

    // Deskripsi
    Widget textSection = const Padding(
      padding: EdgeInsets.all(32),
      child: Text(
        'Pantai Kuta adalah salah satu destinasi wisata paling populer di Bali. '
        'Terkenal dengan pasir putihnya yang panjang dan ombak yang cocok '
        'untuk berselancar, tempat ini selalu ramai dikunjungi wisatawan '
        'lokal maupun mancanegara. Saat sore hari, pantai ini menjadi spot '
        'favorit untuk menikmati matahari terbenam.',
        softWrap: true,
        textAlign: TextAlign.justify,
      ),
    );

    return Material(
      child: ListView(
        children: [
          Image.network(
            'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2069&auto=format&fit=crop',
            width: 600,
            height: 240,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                height: 240,
                color: Colors.grey[300],
                child: const Icon(Icons.broken_image,
                    size: 50, color: Colors.grey),
              );
            },
          ),
          titleSection,
          buttonSection,
          textSection,
        ],
      ),
    );
  }
}
